
 * and open the template in the editor.
 */

/*
 * TelaPrincipal.java
 *
 * Criada em 25/07/2014
 */

/**
 *
 * @author Eduardo Eli Moreira, David Santos.
 */
public class TelaPrincipal extends javax.swing.JFrame {

    /** Cria novo form TelaPrincipal */
    public TelaPrincipal() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        label_data = new java.awt.Label();
        jMenuBar1 = new javax.swing.JMenuBar();
        Menu_Cadastro = new javax.swing.JMenu();
        jMenuItem_clientes = new javax.swing.JMenuItem();
        jMenu_funcionarios = new javax.swing.JMenu();
        jMenuItem_cargo = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem_cidades = new javax.swing.JMenuItem();
        jMenuItem_cidade = new javax.swing.JMenuItem();
        jMenuItem_bairro = new javax.swing.JMenuItem();
        jMenuItem_fornecedores = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenu_estoque = new javax.swing.JMenu();
        jMenuItem_Implantação = new javax.swing.JMenuItem();
        jMenuItem_Entrada = new javax.swing.JMenuItem();
        jMenuItem_Saida = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenuItem_sair = new javax.swing.JMenuItem();
        Menu_Consutas = new javax.swing.JMenu();
        Menu_Relatorios = new javax.swing.JMenu();
        Menu_Utilitarios = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        Menu_Sair = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Software eWeb");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setForeground(new java.awt.Color(0, 153, 255));

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\users_family_(1).png")); 
        jButton1.setText("Clientes");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\users4_(1).png")); 
        jButton2.setText("Funcionarios");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\airplane_(1).png")); 
        jButton3.setText("Fornecedores");

        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\box_(1).png")); 
        jButton4.setText("Estoque");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton2)
                    .addComponent(jButton1)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\minha logo.JPG")); 

        label_data.setText("Data.:");

        Menu_Cadastro.setMnemonic('C');
        Menu_Cadastro.setText("Cadastros");

        jMenuItem_clientes.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\users_family_(1).png")); 
        jMenuItem_clientes.setText("Clietes");
        Menu_Cadastro.add(jMenuItem_clientes);

        jMenu_funcionarios.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\users4_(1).png")); 
        jMenu_funcionarios.setText("Funcionarios");

        jMenuItem_cargo.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\graduate_(1).png")); 
        jMenuItem_cargo.setText("Cargo");
        jMenu_funcionarios.add(jMenuItem_cargo);

        jMenuItem3.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\folhadeponto.gif")); 
        jMenuItem3.setText("Folha de Ponto");
        jMenu_funcionarios.add(jMenuItem3);

        Menu_Cadastro.add(jMenu_funcionarios);

        jMenuItem_cidades.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\houses_(1).png")); 
        jMenuItem_cidades.setText("Cidades");
        Menu_Cadastro.add(jMenuItem_cidades);

        jMenuItem_cidade.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\house_(1).png")); 
        jMenuItem_cidade.setText("Cidade");
        Menu_Cadastro.add(jMenuItem_cidade);

        jMenuItem_bairro.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\press_(1).png")); 
        jMenuItem_bairro.setText("Bairro");
        Menu_Cadastro.add(jMenuItem_bairro);

        jMenuItem_fornecedores.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\airplane_(1).png"));
        jMenuItem_fornecedores.setText("Fornecedores");
        Menu_Cadastro.add(jMenuItem_fornecedores);
        Menu_Cadastro.add(jSeparator1);

        jMenu_estoque.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\box_(1).png"));
        jMenu_estoque.setText("Estoque");

        jMenuItem_Implantação.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\box_add_(1).png"));
        jMenuItem_Implantação.setText("Implantação");
        jMenu_estoque.add(jMenuItem_Implantação);

        jMenuItem_Entrada.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\box_into_(1).png"));
        jMenuItem_Entrada.setText("Entrada");
        jMenu_estoque.add(jMenuItem_Entrada);

        jMenuItem_Saida.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\box_out_(1).png"));
        jMenuItem_Saida.setText("Saida");
        jMenu_estoque.add(jMenuItem_Saida);

        Menu_Cadastro.add(jMenu_estoque);
        Menu_Cadastro.add(jSeparator2);

        jMenuItem_sair.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\Exit.png"));
        jMenuItem_sair.setText("Sair");
        Menu_Cadastro.add(jMenuItem_sair);

        jMenuBar1.add(Menu_Cadastro);

        Menu_Consutas.setMnemonic('n');
        Menu_Consutas.setText("Consultas");
        jMenuBar1.add(Menu_Consutas);

        Menu_Relatorios.setMnemonic('R');
        Menu_Relatorios.setText("Relatórios");
        jMenuBar1.add(Menu_Relatorios);

        Menu_Utilitarios.setMnemonic('U');
        Menu_Utilitarios.setText("Ultilitarios");

        jMenuItem1.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\calendario.gif"));
        jMenuItem1.setText("Data ");
        Menu_Utilitarios.add(jMenuItem1);

        jMenuItem2.setIcon(new javax.swing.ImageIcon("C:\\Documents and Settings\\eduardo.moreira\\Meus documentos\\NetBeansProjects\\Estoque\\Image\\relogio.gif"));
        jMenuItem2.setText("Hora");
        Menu_Utilitarios.add(jMenuItem2);

        jMenuBar1.add(Menu_Utilitarios);

        jMenu1.setText("Ajuda");
        jMenuBar1.add(jMenu1);

        Menu_Sair.setMnemonic('S');
        Menu_Sair.setText("Sair");
        jMenuBar1.add(Menu_Sair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(265, 265, 265)
                        .addComponent(label_data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(label_data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-586)/2, (screenSize.height-438)/2, 586, 438);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu Menu_Cadastro;
    private javax.swing.JMenu Menu_Consutas;
    private javax.swing.JMenu Menu_Relatorios;
    private javax.swing.JMenu Menu_Sair;
    private javax.swing.JMenu Menu_Utilitarios;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem_Entrada;
    private javax.swing.JMenuItem jMenuItem_Implantação;
    private javax.swing.JMenuItem jMenuItem_Saida;
    private javax.swing.JMenuItem jMenuItem_bairro;
    private javax.swing.JMenuItem jMenuItem_cargo;
    private javax.swing.JMenuItem jMenuItem_cidade;
    private javax.swing.JMenuItem jMenuItem_cidades;
    private javax.swing.JMenuItem jMenuItem_clientes;
    private javax.swing.JMenuItem jMenuItem_fornecedores;
    private javax.swing.JMenuItem jMenuItem_sair;
    private javax.swing.JMenu jMenu_estoque;
    private javax.swing.JMenu jMenu_funcionarios;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private java.awt.Label label_data;
    // End of variables declaration//GEN-END:variables

}
